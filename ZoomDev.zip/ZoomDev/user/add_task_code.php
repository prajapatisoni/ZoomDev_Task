<?php
include '../includes/db.php';
include '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $notes = $_POST['notes'];
    $description = $_POST['description'];
    

    $sql = "INSERT INTO tasks (user_id,start_time, stop_time, notes, description) VALUES ('".$_SESSION['user_id']."', '$start_time', '$end_time', '$notes', '$description')";
    
    // echo $sql;die;
    
    if (mysqli_query($conn, $sql)) {
        header("Location: task_list.php?msg=Task successfully added!");
        exit();
    } else {
        header("Location: add_task.php?msg=Error adding user");
        exit();
    }

}
?>