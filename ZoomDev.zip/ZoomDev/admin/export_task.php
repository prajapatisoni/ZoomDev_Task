<?php
include '../includes/db.php';
include '../includes/auth.php';

$filename = "tasks_data.csv";

// Set headers for CSV file download
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');

// Open the output stream
$output = fopen('php://output', 'w');

// Write the CSV column headers
fputcsv($output, array('User Name', 'Start Time', 'End Time', 'Notes', 'Description', 'Date'));

// Fetch the data from the database
$query = "SELECT * FROM tasks";
$result = mysqli_query($conn, $query);

// Fetch each row and write it to the CSV file
while ($row = mysqli_fetch_assoc($result)) {
    $user_details = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM users WHERE id='" . $row['id'] . "'"));
    
    $data = array(
        $user_details['first_name'] . " " . $user_details['last_name'], // User Name
        $row['start_time'],
        $row['stop_time'],
        $row['notes'],
        $row['description'],
        date('d-m-Y', strtotime($row['created_date']))
    );

    // Write the row to CSV
    fputcsv($output, $data);
}

// Close the file and terminate the script
fclose($output);
exit();
?>
