<?php
include '../includes/db.php';
include '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM `admin` WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $pass = $user['password'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    

    if ($user && password_verify($password, $hashed_password)) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['is_admin'] = 1;
        $_SESSION['last_login'] = time();

        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>