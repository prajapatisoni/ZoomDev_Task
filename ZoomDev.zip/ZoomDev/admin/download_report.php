<?php
require '../includes/db.php';
require '../includes/auth.php';

if (!isAdmin()) {
    redirect('../login.php');
}

$stmt = $conn->prepare("SELECT tasks.*, users.first_name, users.last_name FROM tasks JOIN users ON tasks.user_id = users.id");
$stmt->execute();
$result = $stmt->get_result();
$tasks = $result->fetch_all(MYSQLI_ASSOC);

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="tasks_report.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, array('User', 'Start Time', 'Stop Time', 'Notes', 'Description'));

foreach ($tasks as $task) {
    fputcsv($output, array(
        $task['first_name'] . ' ' . $task['last_name'],
        $task['start_time'],
        $task['stop_time'],
        $task['notes'],
        $task['description']
    ));
}

fclose($output);
exit();
?>