<?php include('header.php'); ?>
  <body class="skin-blue">
    <div class="wrapper">
      
    <?php 
      include('head.php');
      include('sidebar.php'); 
    ?>
      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">Add User</h3>
                  <span style="color:red; margin-left:20px; font-size:20px;"><?php echo isset($_GET['msg']) ? htmlspecialchars($_GET['msg']) : ''; ?></span>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form role="form" method="post" action="add_user_code.php">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleName">First Name</label>
                      <input type="text" name="first_name" class="form-control" id="exampleName" placeholder="Enter First Name" autocomplete="off">
                    </div>
                    <div class="form-group">
                      <label for="exampleLastName">Last Name</label>
                      <input type="text" name="last_name" class="form-control" id="exampleLastName" placeholder="Enter Last Name" autocomplete="off">
                    </div>
                    <div class="form-group">
                      <label for="exampleEmail">Email</label>
                      <input type="email" name="email" class="form-control" id="exampleEmail" placeholder="Enter Email" autocomplete="off">
                    </div>
                    <div class="form-group">
                      <label for="exampleMobile">Mobile No.</label>
                      <input type="number" name="mobile" class="form-control" id="exampleMobile" placeholder="Enter Mobile Number" autocomplete="off">
                    </div>




                    <div class="form-group">
                      <label for="exampleInputPassword1">Password</label>
                      <input name="password" type="text" class="form-control" id="exampleInputPassword1" placeholder="Password">
                    </div>
                    <button type="button" class="btn btn-success">Generate Password</button>

                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div><!-- /.box -->
            </div><!--/.col (left) -->
            <!-- right column -->
            
          </div>   <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.0
        </div>
        <strong>Copyright &copy; 2014-2015 <a href="http://almsaeedstudio.com">Almsaeed Studio</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script>
        // Function to generate a random password
        function generateRandomPassword(length) {
            var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
            var password = "";
            for (var i = 0; i < length; i++) {
                var randomIndex = Math.floor(Math.random() * charset.length);
                password += charset[randomIndex];
            }
            return password;
        }

        // jQuery code to generate password on button click
        $("button").click(function() {
            var randomPassword = generateRandomPassword(12); // Change 12 to any length you want
            $("#exampleInputPassword1").val(randomPassword); // Set the generated password in the input field
        });
    </script>

    <?php include('footer.php'); ?>