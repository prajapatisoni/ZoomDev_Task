<?php
require '../includes/db.php';
require '../includes/auth.php';

if (!isAdmin()) {
    redirect('../login.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $auto_generate = isset($_POST['auto_generate']);

    if ($auto_generate) {
        $password = generatePassword();
    }

    if (validatePassword($password)) {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, phone, password_hash) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $first_name, $last_name, $email, $phone, $password_hash);
        if ($stmt->execute()) {
            $success = "User created successfully.";
        } else {
            $error = "Error creating user.";
        }
    } else {
        $error = "Password must be at least 8 characters long.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create User</title>
    <link rel="stylesheet" type="text/css" href="../styles.css">
</head>
<body>
    <h1>Create User</h1>
    <?php if (isset($success)) echo "<p>$success</p>"; ?>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
    <form method="POST">
        <label>First Name:</label>
        <input type="text" name="first_name" required>
        <label>Last Name:</label>
        <input type="text" name="last_name" required>
        <label>Email:</label>
        <input type="email" name="email" required>
        <label>Phone:</label>
        <input type="text" name="phone">
        <label>Password:</label>
        <input type="password" name="password">
        <label>Auto Generate Password:</label>
        <input type="checkbox" name="auto_generate" onchange="togglePasswordField()">
        <button type="submit">Create User</button>
    </form>
    <script>
        function togglePasswordField() {
            var passwordField = document.querySelector('input[name="password"]');
            passwordField.disabled = !passwordField.disabled;
        }
    </script>
</body>
</html>