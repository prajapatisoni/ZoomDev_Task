<?php
include '../includes/db.php';
include '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password_text = $_POST['password'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (first_name, last_name, email, phone, password, password_text) VALUES ('$first_name', '$last_name', '$email', '$mobile', '$password', '$password_text')";
    
    // echo $sql;die;
    
    if (mysqli_query($conn, $sql)) {
        header("Location: user_list.php?msg=User successfully added!");
        exit();
    } else {
        header("Location: add_user.php?msg=Error adding user");
        exit();
    }

}
?>