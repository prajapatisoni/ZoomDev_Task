<?php
$host = 'localhost';
$db = 'task_portal';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


error_reporting(0);
ini_set('display_errors', 0);

?>